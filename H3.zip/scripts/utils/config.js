export const CONFIG = {
  BASE_URL: window.location.origin,
  COMPONENT_PATH: "/components",
  ASSETS_PATH: "/assets",
  API_TIMEOUT: 5000,
};
